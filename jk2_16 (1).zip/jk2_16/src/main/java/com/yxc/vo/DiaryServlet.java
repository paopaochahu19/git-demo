package com.yxc.vo;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class DiaryServlet extends HttpServlet {
	//考虑到隐私性，所以用private,不用public
    private static final long serialVersionUID = 1L;
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    //使用mysql数据库
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/jk2";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "123456";
    // 加载数据库驱动
    static {
        try {
            Class.forName(DRIVER); 
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("数据库驱动加载失败！", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("register".equals(action)) {
            registerUser(request, response);
        } else if ("login".equals(action)) {
            loginUser(request, response);
        } else if ("addDiary".equals(action)) {
            addDiary(request, response);
        } else {
            response.getWriter().println("Invalid action for POST request.");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("logout".equals(action)) {
            logout(request, response);  // 处理登出逻辑
        } else if ("view".equals(action)) {
            listDiaries(request, response);
        } else if ("delete".equals(action)) {
            deleteDiary(request, response);
        } else {
            response.getWriter().println("Invalid action for GET request.");
        }
    }

    private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 使当前会话无效，登出
        HttpSession session = request.getSession();
        session.invalidate();

        // 重定向到登录页面
        response.sendRedirect("index.jsp");
    }

    private void registerUser(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement zyp = conn.prepareStatement(
                     "INSERT INTO diary_users (username, password) VALUES (?, ?)")) {

        	zyp.setString(1, username);
        	zyp.setString(2, password);
        	zyp.executeUpdate();
            response.sendRedirect("index.jsp"); // 注册成功，重定向到登录页

        } catch (SQLIntegrityConstraintViolationException e) { // 用户已存在的错误
            e.printStackTrace();
            response.sendRedirect("register.jsp?error=user_exists");
        } catch (SQLException e) { // 其他数据库错误
            e.printStackTrace();
            response.sendRedirect("register.jsp?error=database_error");
        }
    }

    private void loginUser(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement zyp = conn.prepareStatement(
                     "SELECT * FROM diary_users WHERE username = ? AND password = ?")) {

        	zyp.setString(1, username);
        	zyp.setString(2, password);
            ResultSet rs = zyp.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                response.sendRedirect("diaryPanel.jsp");
            } else {
                request.setAttribute("error", "Invalid credentials");
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp?error=database_error");
        }
    }

    private void addDiary(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String content = request.getParameter("content");
        String username = (String) request.getSession().getAttribute("username");

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement zyp = conn.prepareStatement(
                     "INSERT INTO diaries (username, content) VALUES (?, ?)")) {

        	zyp.setString(1, username);
        	zyp.setString(2, content);
        	zyp.executeUpdate();
            response.sendRedirect("DiaryServlet?action=view");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("diaryPanel.jsp?error=database_error");
        }
    }

    private void listDiaries(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false); // 防止创建新Session
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.jsp"); // 未登录用户，重定向到登录页面
            return;
        }

        String username = (String) session.getAttribute("username");
        ArrayList<Diary> diaries = new ArrayList<>();

        // 分页参数
        int page = 1; 
        int recordsPerPage = 3;

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }
        int start = (page - 1) * recordsPerPage;

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement zyp = conn.prepareStatement(
                     "SELECT * FROM diaries WHERE username = ? LIMIT ?, ?")) {

        	zyp.setString(1, username);
        	zyp.setInt(2, start);
        	zyp.setInt(3, recordsPerPage);
            ResultSet rs = zyp.executeQuery();

            while (rs.next()) {
                diaries.add(new Diary(rs.getInt("id"), rs.getString("username"),
                        rs.getString("content"), rs.getTimestamp("date_created")));
            }

            PreparedStatement countStmt = conn.prepareStatement("SELECT COUNT(*) FROM diaries WHERE username = ?");
            countStmt.setString(1, username);
            ResultSet countRs = countStmt.executeQuery();
            int totalRecords = 0;
            if (countRs.next()) {
                totalRecords = countRs.getInt(1);
            }
            int totalPages = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);

            request.setAttribute("diaries", diaries);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.getRequestDispatcher("viewDiaries.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("diaryPanel.jsp?error=database_error");
        }
    }

    private void deleteDiary(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement zyp = conn.prepareStatement("DELETE FROM diaries WHERE id = ?")) {

        	zyp.setInt(1, id);
        	zyp.executeUpdate();
            response.sendRedirect("DiaryServlet?action=view");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("diaryPanel.jsp?error=database_error");
        }
    }
}