package com.yxc.vo;

import java.sql.Timestamp;

public class Diary {
    private int id;
    private String username;
    private String content;
    private Timestamp dateCreated;

    public Diary(int id, String username, String content, Timestamp dateCreated) {
        this.id = id;
        this.username = username;
        this.content = content;
        this.dateCreated = dateCreated;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getContent() {
        return content;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }
}